package andrealm.td6_exercice1;

public abstract class Application {

    public static final String PIZZA = "pizza";
}
