package andrealm.td6_exercice1;

public interface PizzaAdapterListener {

    public void onClickNom(Pizza item, int position);
    }

