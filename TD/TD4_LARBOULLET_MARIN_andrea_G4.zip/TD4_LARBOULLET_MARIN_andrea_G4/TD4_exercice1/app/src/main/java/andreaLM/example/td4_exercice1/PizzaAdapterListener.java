package andreaLM.example.td4_exercice1;

public class PizzaAdapterListener {

}
