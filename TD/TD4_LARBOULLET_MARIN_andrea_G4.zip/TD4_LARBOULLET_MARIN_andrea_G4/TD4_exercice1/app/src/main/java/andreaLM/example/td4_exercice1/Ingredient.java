package andreaLM.example.td4_exercice1;

public enum Ingredient {
    FROMAGE, CHAMPIGNON, OLIVE
}
