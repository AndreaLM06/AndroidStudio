package AnChEi.projet;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;


public class FlagAdapter extends ListCountry {

    private ListCountry listCountry;

    //Un mécanisme pour gérer l'affichage graphique depuis un layout XML
    private LayoutInflater inflater;

    public FlagAdapter ( ListCountry listCountry){
        this.listCountry = listCountry;
    }

    public int getCount(){return listCountry.size();}

    public Object getItem(int position) {
        return listCountry.getCountry(position);
    }

    public long getItemId(int position) { return position;}

    @SuppressLint("ResourceAsColor")
    public View getView(int position, View convertView, ViewGroup parent) {
        LinearLayout layoutItem;
        //(1) : Réutilisation des layouts
        if (convertView == null) {
            layoutItem = (LinearLayout) inflater.inflate(R.layout.flag_quizz, parent, false);
        } else {
            layoutItem = (LinearLayout) convertView;
        }



        ImageView imgV = layoutItem.findViewById(R.id.imageView);

       // GlideToVectorYou.init().with(CountryFlagActivity.class).load(Uri.parse(listCountry.getCountry(position).getFlagURL()), imgV);


        return layoutItem;
    }




}
