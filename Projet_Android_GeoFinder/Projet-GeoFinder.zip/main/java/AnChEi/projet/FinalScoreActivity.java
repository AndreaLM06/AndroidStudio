package AnChEi.projet;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.util.Arrays;
import java.util.concurrent.TimeUnit;

import nl.dionsegijn.konfetti.core.PartyFactory;
import nl.dionsegijn.konfetti.core.Position;
import nl.dionsegijn.konfetti.core.emitter.Emitter;
import nl.dionsegijn.konfetti.core.emitter.EmitterConfig;
import nl.dionsegijn.konfetti.core.models.Shape;
import nl.dionsegijn.konfetti.xml.KonfettiView;



public class FinalScoreActivity extends AppCompatActivity {
    String finalScore;
    String message;

    Button homeButton;
    TextView scoreView;

    KonfettiView konfettiView;
    Shape.DrawableShape drawableShape;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_score);


        finalScore = String.valueOf(Singleton.getInstance().points);
        scoreView = findViewById(R.id.textViewScoreFinal);
        scoreView.setText(finalScore+"/10");

        konfettiView = findViewById(R.id.konfettiView);
        Drawable drawable = ContextCompat.getDrawable(getApplicationContext(), R.drawable.ic_heart);
        drawableShape = new Shape.DrawableShape(drawable, true);

        konfettiView = findViewById(R.id.konfettiView);

        explode();



        homeButton = findViewById(R.id.buttonBack);
        homeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentHomePage = new Intent(FinalScoreActivity.this, MainActivity.class);
                startActivity(intentHomePage);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.score_menu, menu);
        return true;
    }

    public void explode() {
        EmitterConfig emitterConfig = new Emitter(100L, TimeUnit.MILLISECONDS).max(100);
        konfettiView.start(
                new PartyFactory(emitterConfig)
                        .spread(360)
                        .shapes(Arrays.asList(Shape.Square.INSTANCE, Shape.Circle.INSTANCE, drawableShape))
                        .colors(Arrays.asList(0xfce18a, 0xff726d, 0xf4306d, 0xb48def))
                        .setSpeedBetween(0f, 30f)
                        .position(new Position.Relative(0.5, 0.3))
                        .build()
        );
    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_share_score:
                int pts = Singleton.getInstance().points;
                if (pts==10) message = "J'ai obtenu le score de 10/10 à GeoFinder ! \nPeux-tu égaler mon score ?";
                else if (pts>=7) message = "J'ai obtenu le score de "+ pts + "/10 à GeoFinder !\nTe penses-tu capable de faire mieux que moi ?";
                else if (pts>=4 && pts<7) message = "J'ai obtenu le score de "+ pts + "/10 à GeoFinder.\nJe peux encore m'améliorer mais qu'en est-il de toi ?";
                else if(pts<4 && pts>1) message = "J'ai obtenu le score de "+ pts + "/10 points à GeoFinder.\nCe n'est pas très brillant mais fais-tu mieux que moi ?";
                else if(pts==1) message = "J'ai obtenu le score de 1/10 à GeoFinder.\nC'est mieux que rien mais fais-tu mieux que moi ?";
                else message = "Je n'ai pas obtenu de point à GeoFinder. \nToi, y arriveras-tu ?";

                Intent sendIntent = new Intent();
                sendIntent.setAction(Intent.ACTION_SEND);
                sendIntent.putExtra(Intent.EXTRA_SUBJECT, "Voici mon score sur GeoFinder !");
                sendIntent.putExtra(Intent.EXTRA_TEXT, message);
                sendIntent.setType("message/rfc822");

                Intent shareIntent = Intent.createChooser(sendIntent, null);
                startActivity(shareIntent);
                return true;

            default:
                // If we got here, the user's action was not recognized.
                // Invoke the superclass to handle it.
                return super.onOptionsItemSelected(item);
        }
    }
}
