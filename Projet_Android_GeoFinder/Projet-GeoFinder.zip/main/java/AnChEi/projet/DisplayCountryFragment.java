package AnChEi.projet;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import com.github.twocoffeesoneteam.glidetovectoryou.GlideToVectorYou;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class DisplayCountryFragment extends Fragment {
    private String initialCountry;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //récupération de la valeur de la table
        Bundle arguments = getArguments();
        if(arguments!=null)  {
            initialCountry = getArguments().getString("value");
        }
    }

    EditText editTextCapital;
    EditText editTextRegion;
    EditText editTextLanguage;
    EditText editTextCurrency;
    ImageView imageViewFlag;

    private ProgressDialog pDialog;
    private String url = "https://eideme.github.io/countries-data.json";

    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_display_country, null);
        editTextCapital = rootView.findViewById(R.id.editTextCapital);
        editTextRegion = rootView.findViewById(R.id.editTextRegion);
        editTextLanguage = rootView.findViewById(R.id.editTextLanguage);
        editTextCurrency = rootView.findViewById(R.id.editTextCurrency);
        imageViewFlag = rootView.findViewById(R.id.imageViewFlag);

        new GetCountry().execute();

        return rootView;
    }

    /**
     * Tache asynchrone
     */
    class GetCountry extends AsyncTask<Void, Void, Void> {
        Country country;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = new ProgressDialog(getActivity());
            pDialog.setMessage("Connexion en cours...");
            pDialog.setCancelable(false);
            pDialog.show();
        }

        @Override
        // appelee automatiquement après onPreExecute
        protected Void doInBackground(Void... arg0) {

            String finalCountry = "";

            if (initialCountry != "" && initialCountry.length() > 0) {
                String listCountryName[] = initialCountry.split(" ");
                for (int i = 0; i < listCountryName.length; i++) {
                    if (listCountryName[i] != "and" && listCountryName[i] != "the")
                        finalCountry += listCountryName[i].substring(0, 1).toUpperCase() + listCountryName[i].substring(1).toLowerCase();
                    else finalCountry += listCountryName[i];

                    if (i != (listCountryName.length - 1)) finalCountry += " ";
                }
            } else finalCountry = "";

            HttpHandler sh = new HttpHandler();
            String jsonStr = sh.makeServiceCall(url);

            if (jsonStr != null) {
                try {
                    JSONObject jsonObj = new JSONObject(jsonStr);

                    JSONObject CountryInfo = jsonObj.getJSONObject(finalCountry);

                    JSONObject CountryLanguageInfo = CountryInfo.getJSONObject("language");
                    JSONObject CountryCurrencyInfo = CountryInfo.getJSONObject("currency");

                    // On recupere les infos
                    String CountryCode = CountryInfo.getString("code");
                    String CountryCapital = CountryInfo.getString("capital");
                    String CountryRegion = CountryInfo.getString("region");
                    String CountryLanguage = CountryLanguageInfo.getString("name");

                    String CountryCurrencyName = CountryCurrencyInfo.getString("name");
                    String CountryCurrencySymbol = CountryCurrencyInfo.getString("symbol");

                    String CountryFlagURL = "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/" + CountryCode + ".svg";


                    country = new Country(initialCountry, CountryCapital, CountryRegion, CountryLanguage, CountryCurrencyName, CountryCurrencySymbol, CountryFlagURL);


                } catch (JSONException e) {
                    if (finalCountry == "") country = new Country("Empty");
                    else country = new Country("Error");
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);

            if (country.getName() != "Error" && country.getName() != "Empty") {
                editTextCapital.setText(country.getCapital());
                editTextRegion.setText(country.getRegion());
                editTextLanguage.setText(country.getLanguage());
                editTextCurrency.setText(country.getCurrencyName() + " (" + country.getCurrencySymbol() + ")");
                GlideToVectorYou.init().with(getActivity()).load(Uri.parse(country.getFlagURL()), imageViewFlag);
            } else if (country.getName() == "Error") {
                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                builder.setTitle("Pays non trouvé");
                builder.setMessage("Veuillez vérifier le nom entré.\nPistes :\n - Vérifiez l'orthographe (le nom doit être en anglais !)\n - Vérifiez que le pays existe");
                builder.setCancelable(true);
                builder.setPositiveButton("Compris", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.show();

                editTextCapital.setText("");
                editTextRegion.setText("");
                editTextLanguage.setText("");
                editTextCurrency.setText("");
                imageViewFlag.setImageResource(0);
            }

            if (pDialog.isShowing()) {
                pDialog.dismiss();
            }

        }
    }
}