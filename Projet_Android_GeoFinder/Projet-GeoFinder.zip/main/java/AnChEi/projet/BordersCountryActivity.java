package AnChEi.projet;

import static android.content.ContentValues.TAG;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;

public class BordersCountryActivity extends AppCompatActivity {

    private ListCountry listCountry = new ListCountry();
    TextView txtViewCountry;
    EditText inputCountry;
    Button btnVerify;
    ImageView imgBorder;
    TextView txtResult;

    private String countryName;
    private int min = 0;
    private int max;
    private int nbrandom;
    private int i = 1;



    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_borders);

        Singleton.getInstance().count++;

        listCountry.listBordersImg();

        txtViewCountry = findViewById(R.id.textViewCountry);
        inputCountry = findViewById(R.id.InputCountry);
        btnVerify = findViewById(R.id.buttonVerify);
        imgBorder = findViewById(R.id.imageViewBorder);
        txtResult = findViewById(R.id.textViewResult);

        max = listCountry.size();

        while (i == 1) {
            i = 0;
            nbrandom = (int) (Math.random() * (max - min));
            countryName = listCountry.getCountry(nbrandom).getName();
            for (int j=0;j<Singleton.getInstance().countriesAlreadyPlayed.size();j++) {
                if (countryName == Singleton.getInstance().countriesAlreadyPlayed.get(j)) i = 1;
            }
        }

        imgBorder.setImageResource(listCountry.getCountry(nbrandom).getImgContryC());

        txtViewCountry.setText("A quel pays correspondent ces frontières ?");


        btnVerify.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("ResourceAsColor")
            @Override
            public void onClick(View view) {
                String input = inputCountry.getText().toString();
                hideKeyboardFrom(BordersCountryActivity.this, view);

                AlertDialog.Builder builder = new AlertDialog.Builder(BordersCountryActivity.this);
                if (VerifyBorder(input, countryName)){
                    builder.setMessage("Bravo tu as trouvé ! (+1)");
                    Singleton.getInstance().points++;
                    btnVerify.setBackgroundColor(Color.GREEN);
                }else{
                    builder.setMessage("NON ! Il faut revoir sa géographie !! (+0) \n Le bon pays était : " + countryName);
                    btnVerify.setBackgroundColor(Color.RED);
                }
                Singleton.getInstance().countriesAlreadyPlayed.add(countryName);
                builder.setCancelable(false);
                final AlertDialog alertDialog = builder.create();
                alertDialog.show();
                if (Singleton.getInstance().count == 5) {
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            if (alertDialog.isShowing()){
                                alertDialog.dismiss();
                                Intent intentCountryFlag = new Intent(BordersCountryActivity.this, CountryFlagActivity.class);
                                startActivity(intentCountryFlag);
                                Singleton.getInstance().count = 0;
                                Log.e(TAG, String.valueOf(Singleton.getInstance().count));
                                finish();
                            }
                        }
                    }, 2000);
                }
                else {
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (alertDialog.isShowing()){
                            alertDialog.dismiss();
                            Intent intentCountryBorder = new Intent(BordersCountryActivity.this, BordersCountryActivity.class);
                            overridePendingTransition(0, 0);
                            intentCountryBorder.setFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                            startActivity(intentCountryBorder);
                            finish();
                        }
                    }
                }, 2000); }
            }
        });
    }


    public Boolean VerifyBorder(String inputCountry, String countryName){
        if(!inputCountry.toLowerCase(Locale.ROOT).equals(countryName.toLowerCase(Locale.ROOT))){
            return false;
        }
        return true;
    }

    /**
     * function for hide keyboard from user 'rmirabelle'
     * source : https://stackoverflow.com/questions/1109022/how-do-you-close-hide-the-android-soft-keyboard-programmatically/17789187#17789187
     * @param context
     * @param view
     */
    public static void hideKeyboardFrom(Context context, View view) {
        InputMethodManager imm = (InputMethodManager) context.getSystemService(Activity.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

}
