package AnChEi.projet;

import static android.content.ContentValues.TAG;

import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.github.twocoffeesoneteam.glidetovectoryou.GlideToVectorYou;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class CountryFlagActivity extends AppCompatActivity {

    private ListCountry listCountry = new ListCountry();
    private String randomCountryName;
    private String url = "https://eideme.github.io/countries-data.json";
    private ImageView imgViewFlag;
    private String randomCountryFlagURL;
    private ArrayList<Country> countries = new ArrayList<>();
    private String imgViewFlags = "imgViewFlag";
    private int[] imgViewIds = {
            R.id.imageViewFlag1,
            R.id.imageViewFlag2,
            R.id.imageViewFlag3,
            R.id.imageViewFlag4,
    };
    private int countriesAdded = 0;
    private Boolean countrySeen = false;
    private Country rightCountry;


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_flag_country);

        Singleton.getInstance().count++;
        new GetCountryFlag().execute();
    }


    private class GetCountryFlag extends AsyncTask<Void, Void, Void> {

        @Override
        protected Void doInBackground(Void... params) {
            HttpHandler sh = new HttpHandler();
            String jsonStr = sh.makeServiceCall(url);

            if (jsonStr != null) {
                try {
                    JSONObject jsonObj = new JSONObject(jsonStr);
                    Iterator<String> jsonKeys = jsonObj.keys();
                    List<String> list = new ArrayList<>();
                    jsonKeys.forEachRemaining(list::add);
                    while (countriesAdded < 4) {
                        randomCountryName = list.get((int) (Math.random() * list.size()));
                        for (int j=0;j<Singleton.getInstance().countriesAlreadyPlayed.size();j++) {
                            if (randomCountryName.equals(Singleton.getInstance().countriesAlreadyPlayed.get(j))) {
                                Log.e(TAG, "Pays déjà rencontré :"+randomCountryName);
                                countrySeen = true;
                                break;
                            }
                        }
                        if (!countrySeen) {
                            randomCountryFlagURL = "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/" + jsonObj.getJSONObject(randomCountryName).getString("code") + ".svg";
                            countries.add(new Country(randomCountryName, randomCountryFlagURL));
                            Singleton.getInstance().countriesAlreadyPlayed.add(randomCountryName);
                            countriesAdded++;
                            Log.e("SINGLETON COUNTRIES", Singleton.getInstance().countriesAlreadyPlayed.toString());
                            Log.e(TAG, "Nouveau pays :"+randomCountryName);
                        }
                        countrySeen = false;
                    }
                    countriesAdded = 0;
                } catch (JSONException e) {
                    Log.e(TAG, "Erreur JSON");
                }
            } else {
                Log.e(TAG, "Problème de connexion");
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);

            TextView txtView = findViewById(R.id.randomCountry);
            int rand = (int) (Math.random() * countries.size());
            rightCountry = countries.get(rand);
            Country randomCountry = new Country(null, null);
            countries.remove(rand);
            int rightFlagPosition = (int) (Math.random() * imgViewIds.length);
            txtView.setText("Quel est le drapeau du pays suivant : " + rightCountry.getName());



            for(int i = 0; i < 4; i++) {
                if(!countries.isEmpty()) {
                    randomCountry = countries.get((int) (Math.random() * countries.size()));
                }
                imgViewFlag = findViewById(imgViewIds[i]);



                if(rightFlagPosition == i) {
                    GlideToVectorYou.init().with(CountryFlagActivity.this).load(Uri.parse(rightCountry.getFlagURL()), imgViewFlag);
                    randomCountryName = rightCountry.getName();
                    imgViewFlag.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            AlertDialog.Builder builder = new AlertDialog.Builder(CountryFlagActivity.this);
                            builder.setCancelable(false);
                            builder.setMessage("Bravo ! (+1)");

                            Singleton.getInstance().points++;

                            //Log.d("COUNTRIES SIZE  : ", String.valueOf(Singleton.getInstance().countries.size()));
                            final AlertDialog alertDialog = builder.create();
                            alertDialog.show();


                            if (Singleton.getInstance().count == 5) {
                                new Handler().postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        if (alertDialog.isShowing()) {
                                            alertDialog.dismiss();
                                            Singleton.getInstance().count = 0;
                                            Intent intentFlag = new Intent(CountryFlagActivity.this, FinalScoreActivity.class);
                                            intentFlag.putExtra("scoreFinal", String.valueOf(Singleton.getInstance().points));
                                            startActivity(intentFlag);
                                            finish();
                                        }
                                    }
                                }, 2000);
                            } else {
                                new Handler().postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        if (alertDialog.isShowing()) {
                                            alertDialog.dismiss();
                                            Intent intentCountryFlagActivity = new Intent(CountryFlagActivity.this, CountryFlagActivity.class);
                                            overridePendingTransition(0, 0);
                                            intentCountryFlagActivity.setFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                                            startActivity(intentCountryFlagActivity);
                                            finish();
                                        }
                                    }
                                }, 2000);
                            }
                        }
                    });
                } else {
                    countries.remove(randomCountry);
                    GlideToVectorYou.init().with(CountryFlagActivity.this).load(Uri.parse(randomCountry.getFlagURL()), imgViewFlag);
                    Country finalRandomCountry = randomCountry;
                    imgViewFlag.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            AlertDialog.Builder builder = new AlertDialog.Builder(CountryFlagActivity.this);
                            builder.setCancelable(false);
                            builder.setMessage("Faux ! Vous venez de choisir le drapeau de ce pays : " + finalRandomCountry.getName() + " (+0)");
                            Log.d("COUNTRIES SIZE  : ", String.valueOf(Singleton.getInstance().countriesAlreadyPlayed.size()));
                            final AlertDialog alertDialog = builder.create();
                            alertDialog.show();

                            if (Singleton.getInstance().count == 5) {
                                new Handler().postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        if (alertDialog.isShowing()) {
                                            alertDialog.dismiss();
                                            Intent intentFlag = new Intent(CountryFlagActivity.this, FinalScoreActivity.class);
                                            intentFlag.putExtra("scoreFinal", String.valueOf(Singleton.getInstance().points));
                                            startActivity(intentFlag);
                                            finish();
                                        }
                                    }
                                }, 2000);
                            } else {
                                new Handler().postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        if (alertDialog.isShowing()) {
                                            alertDialog.dismiss();
                                            Intent intentCountryFlagActivity = new Intent(CountryFlagActivity.this, CountryFlagActivity.class);
                                            overridePendingTransition(0, 0);
                                            intentCountryFlagActivity.setFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                                            startActivity(intentCountryFlagActivity);
                                            finish();
                                        }
                                    }
                                }, 2000);
                            }
                        }
                    });
                }

            }
        }
    };
}