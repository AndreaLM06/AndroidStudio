package AnChEi.projet;

import java.util.ArrayList;

public class Singleton {
    public ArrayList<String> countriesAlreadyPlayed;
    public int points;
    public int count;
    private static Singleton instance = new Singleton();

    private Singleton(){}

    public static Singleton getInstance(){
        return instance;
    }
}
