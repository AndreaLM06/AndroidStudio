package AnChEi.projet;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    Button btnInfoCountry;
    Button btnPlay;
    Button btn4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Singleton.getInstance().count = 0;
        btnInfoCountry = findViewById(R.id.btnInfoCountry);
        btnInfoCountry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentSearchCountry = new Intent(MainActivity.this, SearchCountryActivity.class);
                startActivity(intentSearchCountry);
            }
        });

        btnPlay = findViewById(R.id.button1);
        btnPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Animation sur le bouton "Jouer"
                btnPlay.startAnimation(AnimationUtils.loadAnimation(MainActivity.this, R.anim.agrandissement_anim));
                Singleton.getInstance().points = 0;
                Singleton.getInstance().countriesAlreadyPlayed = new ArrayList<String>();
                Intent intentCountryBorder = new Intent(MainActivity.this, BordersCountryActivity.class);
                startActivity(intentCountryBorder);
            }
        });
    }
}