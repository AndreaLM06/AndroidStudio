package AnChEi.projet;

public class Country {

    String name;
    String capital;
    String region;
    String language;
    String currencyName;
    String currencySymbol;
    String flagURL;
    int imgContryC;
    //List<String> listBorders = new ArrayList();

    public Country (String name) {this.name=name;}

    public Country (String name, String flagURL) {
        this.name=name;
        this.flagURL=flagURL;
    }

    /*public Country (String name, List listBorders){
        this.name = name;
        this.listBorders = listBorders;
    }*/

    public Country(String name, int imgContryC){
        this.name = name;
        this.imgContryC = imgContryC;
    }

    public Country (String name, String capital, String region, String language, String currencyName, String currencySymbol, String flagURL){
        this.name = name;
        this.capital=capital;
        this.region=region;
        this.language=language;
        this.currencyName = currencyName;
        this.currencySymbol = currencySymbol;
        this.flagURL = flagURL;
    }

    public String getName() {return name;}

    public String getCapital() {return capital;}

    public String getRegion() {return region;}

    public String getLanguage() {return language;}

    public String getCurrencyName() {return currencyName;}

    public String getCurrencySymbol() {return currencySymbol;}

    public String getFlagURL() {return flagURL;}

    public int getImgContryC() {return imgContryC;}

    // public List<String> getListBorders() {return listBorders;}

    @Override
    public String toString() {
        return "Country{" +
                ", name='" + name + '\'' +
                ", capital='" + capital + '\'' +
                ", region='" + region + '\'' +
                ", language='" + language + '\'' +
                ", currency name='" + currencyName + '\'' +
                ", currency symbol='" + currencySymbol + '\'' +
                ", flag URL='" + flagURL + '\'' +
                '}';
    }
}
