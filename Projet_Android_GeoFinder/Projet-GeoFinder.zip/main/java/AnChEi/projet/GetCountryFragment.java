package AnChEi.projet;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

public class GetCountryFragment extends Fragment {
    @Override
    public View onCreateView(final LayoutInflater inflater, final ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_get_country, container, false);
        EditText inputValue = rootView.findViewById(R.id.InputCountry);

        rootView.findViewById(R.id.ButtonSearchCountry).setOnClickListener( clic -> {
            Fragment fragment;
            FragmentTransaction fragmentTransaction;
            int longueur = inputValue.getText().length();
            if (longueur != 0) {
                String saisie = inputValue.getText().toString();
                fragment = new DisplayCountryFragment();
                Bundle args = new Bundle();
                args.putString("value", saisie);
                fragment.setArguments(args);
                //close keyboard
                InputMethodManager imm = (InputMethodManager)getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(inputValue.getWindowToken(), 0);
                inputValue.setText("");
                try {
                    fragmentTransaction = getParentFragmentManager().beginTransaction().replace(R.id.frame_display_value, fragment);
                    fragmentTransaction.commit();
                } catch (Exception e) {
                    e.printStackTrace();    //erreur fragment non créé
                }
            }
            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                public void run() {
                    rootView.findViewById(R.id.ButtonSearchCountry).setEnabled(true);
                }
            }, 100);
        });

        return rootView;
    } //end onCreate
}